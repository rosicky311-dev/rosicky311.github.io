# Three Kingdoms Duel (Real-time Platform Starter)

Minimal real-time, room-based card-duel platform inspired by turn-based hero card games. No third-party IP or assets included.
Frontend: static HTML+JS. Backend: Node.js + ws. MIT License.

## Quick Start
### Server
cd server
npm install
npm start

### Client
Open client/index.html in browser, set your WS URL.

Deploy: Server to Render/Fly/VPS; Client to GitHub Pages.
