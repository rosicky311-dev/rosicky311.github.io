import express from 'express';
import cors from 'cors';
import http from 'http';
import { WebSocketServer } from 'ws';
import { customAlphabet } from 'nanoid';

const nanoid = customAlphabet('123456789ABCDEFGHJKLMNPQRSTUVWXYZ', 8);
const PORT = process.env.PORT || 8080;

const app = express();
app.use(cors());
app.get('/', (req, res) => res.type('text').send('Three Kingdoms Duel WS server running'));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const clients = new Map(); // ws -> {id, name, roomId}
const rooms = new Map();   // roomId -> {id, name, maxPlayers, players:[{id,name,ready}], game:null|Game}

function broadcastRoom(roomId, payload) {
  for (const [ws, c] of clients) {
    if (c.roomId === roomId && ws.readyState === ws.OPEN) {
      ws.send(JSON.stringify(payload));
    }
  }
}
function send(ws, payload) { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(payload)); }
function listRoomsPublic() {
  return Array.from(rooms.values()).map(r => ({
    id: r.id, name: r.name, maxPlayers: r.maxPlayers, count: r.players.length, playing: !!r.game
  }));
}

function makeDeck() {
  const deck = [];
  for (let i=0;i<20;i++) deck.push({id:`A${i}`, kind:'attack'});
  for (let i=0;i<12;i++) deck.push({id:`D${i}`, kind:'dodge'});
  for (let i=0;i<8;i++)  deck.push({id:`H${i}`, kind:'heal'});
  for (let i=deck.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [deck[i], deck[j]]=[deck[j], deck[i]]; }
  return deck;
}
function createGame(room) {
  const game = {
    deck: makeDeck(), discard: [],
    players: room.players.map(p => ({ id: p.id, name: p.name, hp: 4, hand: [] })),
    turnIndex: 0, phase: 'draw', stack: null, winner: null
  };
  for (const gp of game.players) for (let i=0;i<4;i++) draw(game, gp.id);
  return game;
}
function draw(game, pid, n=2) {
  const gp = game.players.find(x => x.id === pid);
  for (let i=0;i<n;i++) {
    if (game.deck.length === 0) {
      game.deck = game.discard; game.discard = [];
      for (let k=game.deck.length-1;k>0;k--){ const j=Math.floor(Math.random()*(k+1)); [game.deck[k], game.deck[j]]=[game.deck[j], game.deck[k]]; }
    }
    if (game.deck.length === 0) break;
    gp.hand.push(game.deck.pop());
  }
}
function current(game){ return game.players[game.turnIndex]; }
function isAlive(p){ return p.hp > 0; }
function advanceTurn(game) {
  do { game.turnIndex = (game.turnIndex + 1) % game.players.length; }
  while(!isAlive(game.players[game.turnIndex]));
  game.phase = 'draw'; game.stack = null;
}
function checkWinner(game) {
  const alive = game.players.filter(isAlive);
  return alive.length === 1 ? alive[0].id : null;
}
function snapshotFor(ws, room) {
  const client = clients.get(ws); const youId = client?.id; const g = room.game;
  if (!g) return { room: sanitizeRoom(room) };
  const you = g.players.find(p=>p.id===youId);
  return { room: sanitizeRoom(room), game: {
    players: g.players.map(p=>({ id:p.id, name:p.name, hp:p.hp, handSize: p.hand.length })),
    youHand: you ? you.hand : [], turn: g.players[g.turnIndex]?.id,
    phase: g.phase, stack: g.stack, winner: g.winner
  }};
}
function sanitizeRoom(room){
  return { id:room.id, name:room.name, maxPlayers:room.maxPlayers,
    players:room.players.map(p=>({id:p.id, name:p.name, ready:p.ready})) };
}

wss.on('connection', (ws) => {
  const id = nanoid();
  clients.set(ws, { id, name: `Player_${id}`, roomId: null });
  send(ws, { type:'you', playerId: id });

  ws.on('message', (data) => {
    let msg={}; try{ msg=JSON.parse(data.toString()) }catch(e){ return send(ws,{type:'error',message:'Bad JSON'}) }
    const me = clients.get(ws); if (!me) return;

    const emitRooms = () => send(ws, { type:'rooms', rooms: listRoomsPublic() });

    switch(msg.type){
      case 'hello': {
        me.name = String(msg.name||'Player').slice(0,24); emitRooms(); break;
      }
      case 'list_rooms': emitRooms(); break;
      case 'create_room': {
        const name = String(msg.roomName||'Room').slice(0,32);
        const maxPlayers = Math.max(2, Math.min(8, Number(msg.maxPlayers||5)));
        const roomId = nanoid();
        const room = { id:roomId, name, maxPlayers, players:[], game:null };
        rooms.set(roomId, room);
        joinRoom(ws, roomId);
        break;
      }
      case 'join_room': joinRoom(ws, msg.roomId); break;
      case 'leave_room': leaveRoom(ws); break;
      case 'room_chat': {
        const room = rooms.get(me.roomId); if(!room) return;
        broadcastRoom(me.roomId, { type:'chat', from: me.name, text: String(msg.text||'').slice(0,200), at: Date.now() });
        break;
      }
      case 'ready': {
        const room = rooms.get(me.roomId); if(!room) return;
        const p = room.players.find(p=>p.id===me.id); if(!p) return;
        p.ready = !!msg.ready;
        broadcastRoom(me.roomId, { type:'room_update', room: sanitizeRoom(room) });
        break;
      }
      case 'start_game': {
        const room = rooms.get(me.roomId); if(!room) return;
        if(room.game) return send(ws,{type:'error',message:'Game already started'});
        if(room.players.length<2) return send(ws,{type:'error',message:'Need at least 2 players'});
        if(!room.players.every(p=>p.ready)) return send(ws,{type:'error',message:'All players must be ready'});
        room.game = createGame(room);
        broadcastSnapshot(room);
        break;
      }
      case 'play': {
        const room = rooms.get(me.roomId); if(!room || !room.game) return;
        handlePlay(room, me.id, msg); break;
      }
      default: send(ws, { type:'error', message:'Unknown type' });
    }
  });

  ws.on('close', () => { leaveRoom(ws); clients.delete(ws); });
});

function joinRoom(ws, roomId){
  const me = clients.get(ws); if(!me) return;
  const room = rooms.get(roomId);
  if(!room) return send(ws, {type:'error', message:'Room not found'});
  if(room.players.length >= room.maxPlayers) return send(ws, {type:'error', message:'Room is full'});
  leaveRoom(ws);
  room.players.push({ id: me.id, name: me.name, ready: false });
  me.roomId = room.id;
  broadcastRoom(room.id, { type:'room_update', room: sanitizeRoom(room) });
  broadcastSnapshot(room);
}
function leaveRoom(ws){
  const me = clients.get(ws); if(!me || !me.roomId) return;
  const room = rooms.get(me.roomId);
  if(!room) { me.roomId = null; return; }
  room.players = room.players.filter(p=>p.id!==me.id);
  if(room.players.length===0){ rooms.delete(room.id); }
  else {
    if(room.game){
      const gp = room.game.players.find(p=>p.id===me.id);
      if(gp){ gp.hp = 0; }
      const w = checkWinner(room.game);
      if(w){ room.game.winner = w; }
      broadcastSnapshot(room);
    }
    broadcastRoom(room.id, { type:'room_update', room: sanitizeRoom(room) });
  }
  me.roomId = null;
}
function handlePlay(room, pid, msg){
  const g = room.game; if(!g || g.winner) return;
  const me = g.players.find(p=>p.id===pid);
  const mine = me.hand.find(c=>c.id===msg.cardId);
  const yourTurn = g.players[g.turnIndex].id === pid;

  if(g.phase === 'draw' && yourTurn){
    // draw phase: draw 2 by any action
    draw(g, pid, 2); g.phase = 'main'; broadcastSnapshot(room); return;
  }
  if(mine && g.phase === 'main' && yourTurn){
    if(mine.kind === 'attack'){
      const targetId = msg.targetId;
      const target = g.players.find(p=>p.id===targetId && p.hp>0);
      if(!target || targetId===pid) return;
      me.hand = me.hand.filter(c=>c.id!==mine.id); g.discard.push(mine);
      g.stack = { type:'attack', from: pid, to: targetId };
      g.phase = 'react'; broadcastSnapshot(room); return;
    }
    if(mine.kind === 'heal'){
      me.hand = me.hand.filter(c=>c.id!==mine.id); g.discard.push(mine);
      me.hp = Math.min(me.hp + 1, 4); broadcastSnapshot(room); return;
    }
  }
  if(g.phase === 'main' && yourTurn && msg.pass){ g.phase = 'end'; broadcastSnapshot(room); return; }

  if(g.phase === 'react' && g.stack?.type==='attack' && g.stack.to === pid){
    if(mine && mine.kind === 'dodge'){
      const target = g.players.find(p=>p.id===pid);
      target.hand = target.hand.filter(c=>c.id!==mine.id); g.discard.push(mine);
      g.stack = null; g.phase = 'end'; broadcastSnapshot(room); return;
    } else if(msg.pass){
      const target = g.players.find(p=>p.id===pid);
      g.stack = null; target.hp -= 1; if(target.hp<=0) target.hp=0;
      g.phase = 'end'; const w = checkWinner(g); if(w) g.winner = w;
      broadcastSnapshot(room); return;
    }
  }
  if(g.phase === 'end' && yourTurn){ advanceTurn(g); broadcastSnapshot(room); return; }
}
function broadcastSnapshot(room){
  for (const [ws, c] of clients){
    if (c.roomId === room.id && ws.readyState === ws.OPEN){
      send(ws, { type:'game_update', snapshot: snapshotFor(ws, room) });
    }
  }
}

server.listen(PORT, () => { console.log('Server listening on', PORT); });
